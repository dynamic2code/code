import csv

class Bonus:

    def getdata(self):
        file = "Untitled spreadsheet - IMDb_movies.csv"
        global length, countries, data

        countries =[]
        length = []
        with open(file, encoding="utf8") as csvfile:
            reader = csv.reader(csvfile)

            all = []
            for row in reader:
                all.append(row[7])
        # print(all)
        

        data = []
        for i in all:
            indata =(i,all.count(i))
            
            data.append(indata)

        return data

            

    def preparedata(self, data):
        global increment,longest_label_length
       
        max_value = max(count for _, count in data)
        increment = max_value / 25

        longest_label_length = max(len(label) for label, _ in data)

    def makinggraph(self,data, increment,longest_label_length):

        for label, count in data:

            bar_chunks, remainder = divmod(int(count * 8 / increment), 8)
            bar = '█' * bar_chunks
            if remainder > 0:
                bar += chr(ord('█') + (8 - remainder))
            bar = bar or  '▏'

            print(f'{label.rjust(longest_label_length)} ▏ {count:#4d} {bar}')

obj = Bonus()
obj.getdata()
obj.preparedata(data)
obj.makinggraph(data, increment,longest_label_length)